package com.exercise.resttemplate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestTemplateClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
